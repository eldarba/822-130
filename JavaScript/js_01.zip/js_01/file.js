document.getElementById("piska2").innerHTML = "Hello JavaScript 2";
